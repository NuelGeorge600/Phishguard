async function checkUrl() {
  const url = document.getElementById('urlInput').value;
  const resultDiv = document.getElementById('result');
  resultDiv.textContent = 'Checking...';

  const response = await fetch('/api/scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  });

  const data = await response.json();

  if (data.analysis) {
    const stats = data.analysis.data.attributes.stats;
    const malicious = stats.malicious || 0;
    const harmless = stats.harmless || 0;
    resultDiv.innerHTML = \`<p>VirusTotal Analysis:</p><p>Malicious: \${malicious}</p><p>Harmless: \${harmless}</p>\`;
  } else {
    resultDiv.textContent = 'Analysis failed.';
  }
}