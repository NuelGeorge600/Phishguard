# PhishGuard - Fake URL Checker

PhishGuard is a Node.js web app that checks URLs for phishing using client-side detection and the VirusTotal API.

## Developer
**Emmanuel Obele Ngeyai** - Cybersecurity & AI Enthusiast

## Usage
1. Enter a URL to scan
2. Client and VirusTotal scan reports if the link is safe or suspicious