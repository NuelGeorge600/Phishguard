const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.post('/api/scan', async (req, res) => {
  const { url } = req.body;
  const apiKey = process.env.VIRUSTOTAL_API_KEY;

  try {
    const response = await axios.post(
      'https://www.virustotal.com/api/v3/urls',
      new URLSearchParams({ url: url }),
      {
        headers: {
          'x-apikey': apiKey,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    const scanId = response.data.data.id;

    const analysis = await axios.get(
      `https://www.virustotal.com/api/v3/analyses/${scanId}`,
      {
        headers: { 'x-apikey': apiKey },
      }
    );

    res.json({ analysis: analysis.data });
  } catch (error) {
    res.status(500).json({ error: 'VirusTotal analysis failed', details: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});