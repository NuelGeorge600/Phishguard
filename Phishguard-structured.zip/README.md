# PhishGuard
A fake URL and phishing checker powered by client-side rules and VirusTotal API.