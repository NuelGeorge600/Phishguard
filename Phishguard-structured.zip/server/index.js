require('dotenv').config();
console.log('Server running');